from sqlalchemy import Column, Integer, String, Boolean, DateTime, Float, JSON
from sqlalchemy.sql import func
from sqlalchemy.dialects.postgresql import UUID
from .database import Base
import uuid

class MarketingCampaign(Base):
    __tablename__ = "campaign_records"
    __table_args__ = {"schema": "marketing"}

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    campaign_name = Column(String, index=True)
    budget = Column(Float)
    start_date = Column(DateTime)
    metadata_fields = Column(JSON, default={})
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    created_by = Column(String)

class FinanceLedger(Base):
    __tablename__ = "ledger_entries"
    __table_args__ = {"schema": "finance"}

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    entry_type = Column(String)
    amount = Column(Float)
    fiscal_year = Column(Integer)
    metadata_fields = Column(JSON, default={})

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    created_by = Column(String)
