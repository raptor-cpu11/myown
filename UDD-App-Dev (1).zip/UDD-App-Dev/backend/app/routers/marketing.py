from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from .. import models, schemas, database, auth

router = APIRouter(
    prefix="/marketing",
    tags=["marketing"]
)

@router.post("/campaigns", response_model=schemas.Campaign)
def create_campaign(campaign: schemas.CampaignCreate, user: dict = Depends(auth.require_marketing_group), db: Session = Depends(database.get_db)):
    db_campaign = models.MarketingCampaign(**campaign.model_dump())
    db_campaign.created_by = user["email"]
    db.add(db_campaign)
    db.commit()
    db.refresh(db_campaign)
    return db_campaign

@router.get("/campaigns", response_model=List[schemas.Campaign])
def list_campaigns(skip: int = 0, limit: int = 100, user: dict = Depends(auth.require_marketing_group), db: Session = Depends(database.get_db)):
    return db.query(models.MarketingCampaign).offset(skip).limit(limit).all()
