from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from .. import models, schemas, database, auth

router = APIRouter(
    prefix="/finance",
    tags=["finance"]
)

@router.post("/ledger", response_model=schemas.Ledger)
def create_entry(entry: schemas.LedgerCreate, user: dict = Depends(auth.require_finance_group), db: Session = Depends(database.get_db)):
    db_entry = models.FinanceLedger(**entry.model_dump())
    db_entry.created_by = user["email"]
    db.add(db_entry)
    db.commit()
    db.refresh(db_entry)
    return db_entry

@router.get("/ledger", response_model=List[schemas.Ledger])
def list_entries(skip: int = 0, limit: int = 100, user: dict = Depends(auth.require_finance_group), db: Session = Depends(database.get_db)):
    return db.query(models.FinanceLedger).offset(skip).limit(limit).all()
