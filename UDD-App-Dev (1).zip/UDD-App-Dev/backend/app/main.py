from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import text
from .database import engine, Base
from .routers import marketing, finance

app = FastAPI(title="Data Entry API")

# Allow CORS for Next.js frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # Should be restricted in prod
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
def startup_db():
    # Create schemas if they don't exist
    with engine.connect() as connection:
        connection.execute(text("CREATE SCHEMA IF NOT EXISTS marketing"))
        connection.execute(text("CREATE SCHEMA IF NOT EXISTS finance"))
        connection.commit()
    
    # Create tables
    Base.metadata.create_all(bind=engine)

app.include_router(marketing.router)
app.include_router(finance.router)

@app.get("/health")
def health_check():
    return {"status": "ok", "service": "backend"}
