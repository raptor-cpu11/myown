from pydantic import BaseModel
from datetime import datetime, date
from typing import Optional, Dict, Any
import uuid

class CampaignBase(BaseModel):
    campaign_name: str
    budget: float
    start_date: Optional[datetime] = None
    metadata_fields: Optional[Dict[str, Any]] = {}

class CampaignCreate(CampaignBase):
    pass

class Campaign(CampaignBase):
    id: uuid.UUID
    created_at: datetime
    updated_at: Optional[datetime] = None
    created_by: Optional[str] = None

    class Config:
        from_attributes = True

class LedgerBase(BaseModel):
    entry_type: str
    amount: float
    fiscal_year: int
    metadata_fields: Optional[Dict[str, Any]] = {}

class LedgerCreate(LedgerBase):
    pass

class Ledger(LedgerBase):
    id: uuid.UUID
    created_at: datetime
    updated_at: Optional[datetime] = None
    created_by: Optional[str] = None

    class Config:
        from_attributes = True
