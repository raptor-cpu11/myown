import logging
import sys
from fastapi import Header, HTTPException, Depends
from typing import Optional
import json
import base64

# Configure logging
logger = logging.getLogger("auth_logger")
logger.setLevel(logging.INFO)

c_handler = logging.StreamHandler(sys.stdout)
c_handler.setLevel(logging.INFO)

f_handler = logging.FileHandler('auth.log')
f_handler.setLevel(logging.INFO)

c_format = logging.Formatter('%(name)s - %(levelname)s - %(message)s')
f_format = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
c_handler.setFormatter(c_format)
f_handler.setFormatter(f_format)

if not logger.handlers:
    logger.addHandler(c_handler)
    logger.addHandler(f_handler)

def decode_jwt_payload(token: str) -> dict:
    """Helper to decode JWT payload without signature verification."""
    try:
        parts = token.split(".")
        if len(parts) != 3:
            return {}
        payload_b64 = parts[1]
        payload_b64 += "=" * ((4 - len(payload_b64) % 4) % 4)
        decoded_json = base64.urlsafe_b64decode(payload_b64)
        return json.loads(decoded_json)
    except Exception as e:
        logger.error(f"JWT Decode Error: {e}")
        return {}

async def get_current_user(
    x_amzn_oidc_data: Optional[str] = Header(None),
    x_amzn_oidc_accesstoken: Optional[str] = Header(None),
    authorization: Optional[str] = Header(None)
):
    # 1. Local Development / Fallback
    if not any([x_amzn_oidc_data, x_amzn_oidc_accesstoken, authorization]):
        logger.info("Auth: No headers found, returning mock local user.")
        return {"email": "local-dev@example.com", "groups": ["Marketing", "Finance"]}

    email = "unknown_user"
    groups = []

    # 2. Extract Email from Identity Token (x-amzn-oidc-data)
    if x_amzn_oidc_data:
        claims = decode_jwt_payload(x_amzn_oidc_data)
        email = claims.get("email") or claims.get("username") or email
        # If access token is missing, try to get groups from here as fallback
        if not x_amzn_oidc_accesstoken:
             groups = claims.get("cognito:groups", [])

    # 3. Extract Groups from Access Token (x-amzn-oidc-accesstoken)
    # User priority: Access Token for Groups
    if x_amzn_oidc_accesstoken:
        claims = decode_jwt_payload(x_amzn_oidc_accesstoken)
        groups = claims.get("cognito:groups", [])
        # Fallback email if Identity Token was missing
        if not x_amzn_oidc_data:
            email = claims.get("username") or email

    # 4. Standard Authorization Header Fallback
    if not x_amzn_oidc_data and not x_amzn_oidc_accesstoken and authorization:
        if authorization.startswith("Bearer "):
            token = authorization.split(" ")[1]
            claims = decode_jwt_payload(token)
            email = claims.get("email") or claims.get("username") or email
            groups = claims.get("cognito:groups", [])

    # Normalize groups (sometimes it's a list, sometimes a string if custom claims)
    if isinstance(groups, str):
        groups = groups.split(",")

    logger.info(f"Auth User: {email}, Groups: {groups}")

    return {
        "email": email,
        "groups": groups
    }

async def require_marketing_group(user: dict = Depends(get_current_user)):
    if "Marketing" in user["groups"] or "local-dev@example.com" == user["email"]:
        return user
    raise HTTPException(status_code=403, detail="Access Denied: Marketing Group Required")

async def require_finance_group(user: dict = Depends(get_current_user)):
    if "Finance" in user["groups"] or "local-dev@example.com" == user["email"]:
        return user
    raise HTTPException(status_code=403, detail="Access Denied: Finance Group Required")
