import Sidebar from "../components/Sidebar";
import "./globals.css";
import { headers } from "next/headers";

export const metadata = {
  title: "Oversite - Data Entry",
  description: "Role-based data entry application",
};

async function getUserEmailFromHeaders(): Promise<string> {
  const headersList = await headers();
  const albData = headersList.get("x-amzn-oidc-data");

  if (albData) {
    try {
      // Decode JWT payload (index 1)
      const payload = albData.split('.')[1];
      // Fix Base64 URL encoding
      const base64 = payload.replace(/-/g, '+').replace(/_/g, '/');
      const paddedBase64 = base64.padEnd(base64.length + (4 - base64.length % 4) % 4, '=');

      const jsonPayload = Buffer.from(paddedBase64, 'base64').toString('utf-8');
      const claims = JSON.parse(jsonPayload);

      return claims.email || claims.username || "unknown@example.com";
    } catch (e) {
      console.error("Failed to parse ALB header", e);
    }
  }
  return "dev-user@example.com";
}

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const userEmail = await getUserEmailFromHeaders();

  return (
    <html lang="en">
      <body style={{ display: "flex", margin: 0 }}>
        <Sidebar userEmail={userEmail} />
        <main style={{ flex: 1, padding: "2rem", overflowY: "auto", height: "100vh" }}>
          {children}
        </main>
      </body>
    </html>
  );
}
