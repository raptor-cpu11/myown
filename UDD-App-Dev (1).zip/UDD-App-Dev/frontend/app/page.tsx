import Link from "next/link";
import { Coins, Megaphone, Settings, Activity } from "lucide-react";

export default function Dashboard() {
  return (
    <div>
      <h1 style={{ fontSize: "2rem", marginBottom: "1rem" }}>Dashboard</h1>
      <p style={{ marginBottom: "2rem", color: "#666" }}>Select a business unit to manage data.</p>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: "1.5rem" }}>

        <Link href="/marketing" style={{ textDecoration: "none", color: "inherit" }}>
          <div style={{ background: "white", padding: "1.5rem", borderRadius: "8px", border: "1px solid #e0e0e0", cursor: "pointer", transition: "transform 0.2s" }} className="hover:scale-105">
            <div style={{ display: "flex", alignItems: "center", gap: "1rem", marginBottom: "1rem" }}>
              <div style={{ padding: "0.75rem", background: "#e6f0ff", borderRadius: "8px", color: "#0066cc" }}>
                <Megaphone size={24} />
              </div>
              <h3 style={{ margin: 0 }}>Marketing</h3>
            </div>
            <p style={{ color: "#666", margin: "0 0 1rem 0" }}>Manage campaigns, budgets, and schedules.</p>
            <span style={{ color: "green", fontSize: "0.875rem", fontWeight: "bold" }}>12 Active Campaigns</span>
          </div>
        </Link>

        <Link href="/finance" style={{ textDecoration: "none", color: "inherit" }}>
          <div style={{ background: "white", padding: "1.5rem", borderRadius: "8px", border: "1px solid #e0e0e0", cursor: "pointer", transition: "transform 0.2s" }} className="hover:scale-105">
            <div style={{ display: "flex", alignItems: "center", gap: "1rem", marginBottom: "1rem" }}>
              <div style={{ padding: "0.75rem", background: "#fff0e6", borderRadius: "8px", color: "#cc6600" }}>
                <Coins size={24} />
              </div>
              <h3 style={{ margin: 0 }}>Finance</h3>
            </div>
            <p style={{ color: "#666", margin: "0 0 1rem 0" }}>Track revenue, expenses, and ledger entries.</p>
            <span style={{ color: "gray", fontSize: "0.875rem", fontWeight: "bold" }}>4 Pending Approvals</span>
          </div>
        </Link>

        <Link href="#" style={{ textDecoration: "none", color: "inherit", opacity: 0.7 }}>
          <div style={{ background: "white", padding: "1.5rem", borderRadius: "8px", border: "1px solid #e0e0e0", cursor: "not-allowed" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "1rem", marginBottom: "1rem" }}>
              <div style={{ padding: "0.75rem", background: "#f0f0f0", borderRadius: "8px", color: "#666" }}>
                <Activity size={24} />
              </div>
              <h3 style={{ margin: 0 }}>Operations</h3>
            </div>
            <p style={{ color: "#666", margin: "0 0 1rem 0" }}>Logistics and operational workflows.</p>
            <span style={{ background: "#eee", padding: "0.25rem 0.5rem", borderRadius: "4px", fontSize: "0.75rem" }}>Coming Soon</span>
          </div>
        </Link>

      </div>
    </div>
  );
}
