"use client";

import { useState, useEffect } from "react";
import DataGrid from "../../components/DataGrid";
import BulkUploadModal from "../../components/BulkUploadModal";
import DataEntryForm from "../../components/DataEntryForm";

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export default function MarketingPage() {
    const [data, setData] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const [isUploadOpen, setIsUploadOpen] = useState(false);
    const [isEntryOpen, setIsEntryOpen] = useState(false);

    const columns = [
        { key: "campaign_name", label: "Campaign Name" },
        { key: "budget", label: "Budget ($)" },
        { key: "start_date", label: "Start Date" },
        { key: "status", label: "Status" },
    ];

    const formFields = [
        { key: "campaign_name", label: "Campaign Name", type: "text" },
        { key: "budget", label: "Budget", type: "number" },
        { key: "start_date", label: "Start Date", type: "date" },
        { key: "status", label: "Status", type: "select", options: ["Active", "Planned", "Completed"] },
    ] as const;

    const fetchData = async () => {
        setLoading(true);
        try {
            // Using /marketing prefix based on main.py router prefix
            const res = await fetch(`${API_BASE}/marketing/campaigns`);
            if (!res.ok) throw new Error("Failed to fetch data");
            const result = await res.json();
            setData(result);
        } catch (err) {
            console.error(err);
            setError("Could not load campaigns.");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, []);

    const postData = async (items: any[]) => {
        // Simple loop for now. In real app, could be a bulk endpoint.
        for (const item of items) {
            const payload = {
                campaign_name: item.campaign_name || item["Campaign Name"],
                budget: Number(item.budget || item["Budget"]),
                start_date: item.start_date || item["Start Date"],
                status: item.status || "Planned"
            };

            await fetch(`${API_BASE}/marketing/campaigns`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload)
            });
        }
        await fetchData(); // Refresh list
    };

    const handleBulkUpload = async (uploadedData: any[]) => {
        await postData(uploadedData);
        setIsUploadOpen(false);
    };

    const handleEntrySubmit = async (newRecords: any[]) => {
        await postData(newRecords);
        setIsEntryOpen(false);
    };

    return (
        <div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "2rem" }}>
                <div>
                    <h1 style={{ margin: 0 }}>Marketing Campaigns</h1>
                    <p style={{ color: "#666" }}>Manage marketing budgets and schedules</p>
                </div>
                <div style={{ display: "flex", gap: "1rem" }}>
                    <button
                        style={{
                            background: "white",
                            color: "#333",
                            border: "1px solid #ccc",
                            padding: "0.75rem 1.5rem",
                            borderRadius: "4px",
                            cursor: "pointer"
                        }}
                        onClick={() => setIsUploadOpen(true)}
                    >
                        Upload CSV/Excel
                    </button>
                    <button
                        style={{
                            background: "#0066cc",
                            color: "white",
                            border: "none",
                            padding: "0.75rem 1.5rem",
                            borderRadius: "4px",
                            cursor: "pointer",
                            fontWeight: "bold"
                        }}
                        onClick={() => setIsEntryOpen(true)}
                    >
                        + New Campaign
                    </button>
                </div>
            </div>

            {loading && <p>Loading data...</p>}
            {error && <p style={{ color: 'red' }}>{error}</p>}

            {!loading && !error && (
                isEntryOpen ? (
                    <DataEntryForm
                        fields={formFields as any}
                        onSubmit={handleEntrySubmit}
                        onCancel={() => setIsEntryOpen(false)}
                    />
                ) : (
                    <DataGrid
                        columns={columns}
                        data={data}
                        onEdit={(item) => console.log("Edit", item)}
                        onDelete={(item) => console.log("Delete", item)}
                    />
                )
            )}

            <BulkUploadModal
                isOpen={isUploadOpen}
                onClose={() => setIsUploadOpen(false)}
                onUpload={handleBulkUpload}
                title="Upload Marketing Data"
            />
        </div>
    );
}
