"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import styles from "./Sidebar.module.css";
import { LayoutDashboard, Coins, Megaphone, Settings, LogOut } from "lucide-react";

interface SidebarProps {
    userEmail?: string;
}

export default function Sidebar({ userEmail = "user@example.com" }: SidebarProps) {
    const pathname = usePathname();

    const links = [
        { href: "/", label: "Dashboard", icon: LayoutDashboard },
        { href: "/marketing", label: "Marketing", icon: Megaphone },
        { href: "/finance", label: "Finance", icon: Coins },
        { href: "/settings", label: "Settings", icon: Settings },
    ];

    return (
        <aside className={styles.sidebar}>
            <div className={styles.logo}>
                <LayoutDashboard size={28} />
                <span>Oversite</span>
            </div>
            <nav className={styles.nav}>
                {links.map((link) => {
                    const Icon = link.icon;
                    const isActive = pathname === link.href;
                    return (
                        <Link
                            key={link.href}
                            href={link.href}
                            className={`${styles.navItem} ${isActive ? styles.active : ""}`}
                        >
                            <Icon size={20} />
                            <span>{link.label}</span>
                        </Link>
                    );
                })}
            </nav>

            <div style={{ marginTop: "auto", borderTop: "1px solid var(--border)", paddingTop: "1rem" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "0.75rem", padding: "0.75rem 1rem", color: "var(--secondary-foreground)" }}>
                    <div style={{ width: "32px", height: "32px", borderRadius: "50%", background: "#ccc", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: "bold", color: "white" }}>
                        U
                    </div>
                    <div style={{ fontSize: "0.875rem", overflow: "hidden", textOverflow: "ellipsis" }}>
                        <div style={{ fontWeight: "600" }}>User Profile</div>
                        <div style={{ fontSize: "0.75rem", opacity: 0.7 }}>{userEmail}</div>
                    </div>
                </div>

                <Link
                    href="/api/auth/logout"
                    className={styles.navItem}
                    style={{ marginTop: "0.5rem", color: "#d32f2f" }}
                    onClick={(e) => {
                        // If we are behind ALB, we might want to hit the Cognito logout endpoint
                        // For now, this is a placeholder link
                        e.preventDefault();
                        window.location.href = "https://your-alb-dns.us-east-1.elb.amazonaws.com/oauth2/logout";
                    }}
                >
                    <LogOut size={20} />
                    <span>Log Out</span>
                </Link>
            </div>
        </aside>
    );
}
