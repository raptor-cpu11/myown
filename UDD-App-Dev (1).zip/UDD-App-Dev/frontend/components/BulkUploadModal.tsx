"use client";

import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import * as XLSX from "xlsx";
import { Upload, X, FileSpreadsheet, CheckCircle, AlertCircle } from "lucide-react";
import styles from "./BulkUploadModal.module.css";

interface BulkUploadModalProps {
    isOpen: boolean;
    onClose: () => void;
    onUpload: (data: any[]) => void;
    title?: string;
}

export default function BulkUploadModal({ isOpen, onClose, onUpload, title = "Bulk Upload" }: BulkUploadModalProps) {
    const [file, setFile] = useState<File | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [data, setData] = useState<any[]>([]);

    const onDrop = useCallback((acceptedFiles: File[]) => {
        const uploadedFile = acceptedFiles[0];
        setFile(uploadedFile);
        setError(null);
        setData([]);

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const bstr = e.target?.result;
                const wb = XLSX.read(bstr, { type: "binary" });
                const wsname = wb.SheetNames[0];
                const ws = wb.Sheets[wsname];
                const jsonData = XLSX.utils.sheet_to_json(ws);

                if (jsonData.length === 0) {
                    setError("File is empty or invalid format.");
                } else {
                    setData(jsonData);
                }
            } catch (err) {
                setError("Failed to parse file. Please convert to standard CSV or Excel format.");
                console.error(err);
            }
        };
        reader.readAsBinaryString(uploadedFile);
    }, []);

    const { getRootProps, getInputProps, isDragActive } = useDropzone({
        onDrop,
        accept: {
            'text/csv': ['.csv'],
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
            'application/vnd.ms-excel': ['.xls']
        },
        maxFiles: 1
    });

    const handleUpload = () => {
        if (data.length > 0) {
            onUpload(data);
            handleClose();
        }
    };

    const handleClose = () => {
        setFile(null);
        setData([]);
        setError(null);
        onClose();
    };

    if (!isOpen) return null;

    return (
        <div className={styles.overlay}>
            <div className={styles.modal}>
                <div className={styles.header}>
                    <h2 style={{ margin: 0 }}>{title}</h2>
                    <button className={styles.closeBtn} onClick={handleClose}>
                        <X />
                    </button>
                </div>

                <div
                    {...getRootProps()}
                    className={`${styles.dropzone} ${isDragActive ? styles.active : ""}`}
                >
                    <input {...getInputProps()} />
                    <Upload size={48} color={isDragActive ? "#0066cc" : "#ccc"} style={{ marginBottom: "1rem" }} />
                    {isDragActive ? (
                        <p style={{ margin: 0, color: "#0066cc" }}>Drop the file here...</p>
                    ) : (
                        <div>
                            <p style={{ margin: 0, fontWeight: "bold" }}>Drag & drop a CSV or Excel file</p>
                            <p style={{ margin: "0.5rem 0 0", color: "#666", fontSize: "0.875rem" }}>or click to select file</p>
                        </div>
                    )}
                </div>

                {error && (
                    <div style={{ marginTop: "1rem", color: "#d32f2f", display: "flex", alignItems: "center", gap: "0.5rem", fontSize: "0.875rem" }}>
                        <AlertCircle size={16} />
                        {error}
                    </div>
                )}

                {file && !error && (
                    <div className={styles.fileInfo}>
                        <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
                            <FileSpreadsheet color="#217346" size={20} />
                            <div>
                                <p style={{ margin: 0, fontWeight: "500" }}>{file.name}</p>
                                <p style={{ margin: 0, fontSize: "0.75rem", color: "#666" }}>{data.length} records found</p>
                            </div>
                        </div>
                        <CheckCircle color="green" size={20} />
                    </div>
                )}

                <div className={styles.actions}>
                    <button className={styles.cancelBtn} onClick={handleClose}>Cancel</button>
                    <button
                        className={styles.uploadBtn}
                        disabled={!file || !!error || data.length === 0}
                        onClick={handleUpload}
                    >
                        Upload {data.length > 0 ? `(${data.length})` : ""}
                    </button>
                </div>
            </div>
        </div>
    );
}
