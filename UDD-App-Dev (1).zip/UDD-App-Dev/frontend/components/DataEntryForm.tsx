"use client";

import { useState } from "react";
import { Plus, Trash2, X } from "lucide-react";
import styles from "./DataEntryForm.module.css";

interface Field {
    key: string;
    label: string;
    type: "text" | "number" | "date" | "select";
    options?: string[]; // For select type
}

interface DataEntryFormProps {
    fields: Field[];
    onSubmit: (data: any[]) => void;
    onCancel: () => void;
}

export default function DataEntryForm({ fields, onSubmit, onCancel }: DataEntryFormProps) {
    const [mode, setMode] = useState<"single" | "multi">("single");
    const [rows, setRows] = useState<any[]>([{}]);

    const handleModeChange = (newMode: "single" | "multi") => {
        setMode(newMode);
        if (newMode === "single") {
            setRows([rows[0] || {}]);
        }
    };

    const handleChange = (index: number, key: string, value: any) => {
        const newRows = [...rows];
        newRows[index] = { ...newRows[index], [key]: value };
        setRows(newRows);
    };

    const addRow = () => {
        setRows([...rows, {}]);
    };

    const removeRow = (index: number) => {
        if (rows.length === 1) return;
        const newRows = rows.filter((_, i) => i !== index);
        setRows(newRows);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSubmit(rows);
    };

    return (
        <div className={styles.formContainer}>
            <div className={styles.header}>
                <div style={{ display: "flex", alignItems: "center", gap: "1rem" }}>
                    <h2 style={{ margin: 0 }}>Add New Records</h2>
                    <div className={styles.modeSwitch}>
                        <button
                            className={`${styles.modeBtn} ${mode === "single" ? styles.activeMode : ""}`}
                            onClick={() => handleModeChange("single")}
                        >
                            Single Entry
                        </button>
                        <button
                            className={`${styles.modeBtn} ${mode === "multi" ? styles.activeMode : ""}`}
                            onClick={() => handleModeChange("multi")}
                        >
                            Multi-Row
                        </button>
                    </div>
                </div>
                <button className={styles.removeBtn} onClick={onCancel} title="Close">
                    <X size={20} />
                </button>
            </div>

            <form onSubmit={handleSubmit}>
                {rows.map((row, index) => (
                    <div
                        key={index}
                        className={styles.row}
                        style={{
                            gridTemplateColumns: `repeat(${fields.length}, 1fr) ${mode === "multi" ? "40px" : ""}`,
                            borderBottom: mode === "multi" ? "1px solid #f0f0f0" : "none",
                            paddingBottom: mode === "multi" ? "1rem" : "0"
                        }}
                    >
                        {fields.map((field) => (
                            <div key={field.key} className={styles.field}>
                                {index === 0 && <label className={styles.label}>{field.label}</label>}
                                {field.type === "select" ? (
                                    <select
                                        className={styles.input}
                                        value={row[field.key] || ""}
                                        onChange={(e) => handleChange(index, field.key, e.target.value)}
                                        required
                                    >
                                        <option value="">Select...</option>
                                        {field.options?.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                                    </select>
                                ) : (
                                    <input
                                        type={field.type}
                                        className={styles.input}
                                        value={row[field.key] || ""}
                                        onChange={(e) => handleChange(index, field.key, e.target.value)}
                                        placeholder={field.label}
                                        required
                                    />
                                )}
                            </div>
                        ))}

                        {mode === "multi" && (
                            <button
                                type="button"
                                className={styles.removeBtn}
                                onClick={() => removeRow(index)}
                                disabled={rows.length === 1}
                            >
                                <Trash2 size={18} />
                            </button>
                        )}
                    </div>
                ))}

                <div className={styles.actions}>
                    <div>
                        {mode === "multi" && (
                            <button type="button" className={styles.addBtn} onClick={addRow}>
                                <Plus size={16} /> Add another row
                            </button>
                        )}
                    </div>
                    <div style={{ display: "flex", gap: "1rem" }}>
                        <button type="button" className={styles.cancelBtn} onClick={onCancel}>
                            Cancel
                        </button>
                        <button type="submit" className={styles.submitBtn}>
                            Save {rows.length} Record{rows.length !== 1 ? "s" : ""}
                        </button>
                    </div>
                </div>
            </form>
        </div>
    );
}
