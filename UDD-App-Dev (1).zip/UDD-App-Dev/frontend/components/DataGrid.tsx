"use client";

import styles from "./DataGrid.module.css";
import { Edit2, Trash2 } from "lucide-react";

interface Column {
    key: string;
    label: string;
}

interface DataGridProps {
    columns: Column[];
    data: any[];
    onEdit?: (item: any) => void;
    onDelete?: (item: any) => void;
}

export default function DataGrid({ columns, data, onEdit, onDelete }: DataGridProps) {
    return (
        <div className={styles.gridContainer}>
            <table className={styles.table}>
                <thead>
                    <tr className={styles.tr}>
                        {columns.map((col) => (
                            <th key={col.key} className={styles.th}>
                                {col.label}
                            </th>
                        ))}
                        {(onEdit || onDelete) && <th className={styles.th}>Actions</th>}
                    </tr>
                </thead>
                <tbody>
                    {data.map((row, i) => (
                        <tr key={i} className={styles.tr}>
                            {columns.map((col) => (
                                <td key={col.key} className={styles.td}>
                                    {row[col.key]}
                                </td>
                            ))}
                            {(onEdit || onDelete) && (
                                <td className={styles.td}>
                                    {onEdit && (
                                        <button className={styles.actionBtn} onClick={() => onEdit(row)}>
                                            <Edit2 size={16} />
                                        </button>
                                    )}
                                    {onDelete && (
                                        <button className={styles.actionBtn} onClick={() => onDelete(row)}>
                                            <Trash2 size={16} />
                                        </button>
                                    )}
                                </td>
                            )}
                        </tr>
                    ))}
                    {data.length === 0 && (
                        <tr>
                            <td colSpan={columns.length + (onEdit || onDelete ? 1 : 0)} className={styles.td} style={{ textAlign: "center", padding: "2rem" }}>
                                No records found.
                            </td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
    );
}
