---
title: "UDD - AG Build"
created_at: 06-01-2026 12:47 AM
updated_at: 06-01-2026 02:00 AM
tags: 
---

# UDD - AG Build

# **Walkthrough - Role-Based Data Entry Application**

I have implemented the application with a modular structure: `frontend`, `backend`, and `infrastructure`.

## **Application Structure**

### **Backend (`/backend`)**

- **Framework**: FastAPI (Python)
- **Database**: PostgreSQL with SQLAlchemy (Multi-schema: `marketing`, `finance`)
- **Key Files**:
    - `app/main.py`: Entry point, creates schemas on startup.
    - `app/models.py`: Database models for Campaign and Ledger.
    - `app/routers/`: Separate endpoints for Marketing and Finance.

### **Frontend (`/frontend`)**

- **Framework**: Next.js 14+ (App Router)
- **Styling**: CSS Modules + Global Design System (Variables).
- **Key Components**:
    - `components/Sidebar.tsx`: Navigation.
    - `components/DataGrid.tsx`: Reusable table component.
    - `components/BulkUploadModal.tsx`: Generic CSV/Excel upload modal.
    - `components/DataEntryForm.tsx`: Generic form for single and multi-row entry.
    - `app/marketing/page.tsx` & `app/finance/page.tsx`: Business function pages with integrated upload/entry features.

### **Infrastructure (`/infrastructure`)**

- **Docker Compose**: Orchestrates Backend + PostgreSQL.
- **Frontend Dockerfile**: Multi-stage build for production-ready frontend.

## **New Features Implemented**

1. **Dashboard Enhancements**: Explicitly lists Marketing, Finance, and Operations sub-apps.
2. **Bulk Upload**: Supports both CSV and Excel (`.xlsx`) files.
3. **Data Entry**:
    - **Single Entry**: Form mode for adding one record.
    - **Multi-Row Entry**: Dynamic grid for adding multiple records at once.

## **How to Run**

### **1\. Start Backend & Database**

navigate to `infrastructure` and run:

```
docker-compose up --build
```

This will start:

- PostgreSQL on port `5432`.
- FastAPI Backend on port `8000`.

### **2\. Start Frontend**

Navigate to `frontend`. **Development:**

```
npm run dev
```

**Production (Docker):** Build and run the frontend container (requires building the image first).

## **Verification Results**

### **Frontend**

- **Build Status**: ✅ Passed (`npm run build`)
- **Type Safety**: ✅ TypeScript checks passed.
- **Routing**: Verified pages at `/marketing` and `/finance`.

### **Backend**

- Code structure implemented with Pydantic schemas and SQLAlchemy models.
- Database models configured for multi-schema isolation (`marketing`, `finance`).

