# deploy.ps1 - Deployment Script for Windows/PowerShell

$AWS_REGION = "us-east-1"
$AWS_ACCOUNT_ID = "YOUR_ACCOUNT_ID" # Replace with actual ID
$ENV = "dev"
$ECR_FRONTEND = "$AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/$ENV-frontend"
$ECR_BACKEND = "$AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/$ENV-backend"

Write-Host "Authenticating with ECR..."
aws ecr get-login-password --region $AWS_REGION | docker login --username AWS --password-stdin "$AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com"

# Build and Push Backend
Write-Host "Building Backend..."
docker build -t "$ENV-backend:latest" ../backend
docker tag "$ENV-backend:latest" "$ECR_BACKEND:latest"

Write-Host "Pushing Backend..."
docker push "$ECR_BACKEND:latest"

# Build and Push Frontend
Write-Host "Building Frontend..."
docker build -t "$ENV-frontend:latest" ../frontend
docker tag "$ENV-frontend:latest" "$ECR_FRONTEND:latest"

Write-Host "Pushing Frontend..."
docker push "$ECR_FRONTEND:latest"

Write-Host "Deployment Images Pushed Successfully!"
Write-Host "Now run: terraform apply -var='db_password=YOUR_SECURE_PASSWORD' in infrastructure/terraform"
